## composer install 오류 발생 시

```
Your lock file does not contain a compatible set of packages. Please run composer update.

  Problem 1
    - cknow/laravel-money is locked to version v7.2.0 and an update of this package was not requested.
    - cknow/laravel-money v7.2.0 requires ext-intl * -> it is missing from your system. Install or enable PHP's intl extension.
  Problem 2
    - phpoffice/phpspreadsheet is locked to version 1.29.0 and an update of this package was not requested.
    - phpoffice/phpspreadsheet 1.29.0 requires ext-gd * -> it is missing from your system. Install or enable PHP's gd extension.
  Problem 3
    - marvel/shop is locked to version dev-master and an update of this package was not requested.
    - cknow/laravel-money v7.2.0 requires ext-intl * -> it is missing from your system. Install or enable PHP's intl extension.
    - marvel/shop dev-master requires cknow/laravel-money 7.2.0 -> satisfiable by cknow/laravel-money[v7.2.0].
    - cknow/laravel-money v7.2.0 requires ext-intl * -> it is missing from your system. Install or enable PHP's intl extension.
    - cknow/laravel-money v7.2.0 requires ext-intl * -> it is missing from your system. Install or enable PHP's intl extension.
    - marvel/shop dev-master requires cknow/laravel-money 7.2.0 -> satisfiable by cknow/laravel-money[v7.2.0].

To enable extensions, verify that they are enabled in your .ini files:
    - C:\xampp\php\php.ini
You can also run `php --ini` in a terminal to see which files are used by PHP in CLI mode.
Alternatively, you can run Composer with `--ignore-platform-req=ext-intl --ignore-platform-req=ext-gd` to temporarily ignore these required extensions.
```

#### php.ini 파일에서 아래 코드 주석 해제

- extension=intl
- extension=gd
- extension=zip

## php artisan marvel:install License Key

`ea0004f1-aaff-4f4e-9611-bef1cfe9a029`

#### mail server 등록 필요 시

표에 나와있는 명령어 입력 후 작업

```
You need to configure your mail server for proper application performance.

Do you want to configure mail server.

Are you sure! (yes/no) [yes]
❯ no

You can configuration by below command or manual process.

┌───────────────────┬───────────────────────────────────────┐
│ Command │ Details │                                       │
├───────────────────┼───────────────────────────────────────┤
│ marvel:mail-setup │ Mail setup (mailtrap, mailgun, gmail) │
└───────────────────┴───────────────────────────────────────┘
```
